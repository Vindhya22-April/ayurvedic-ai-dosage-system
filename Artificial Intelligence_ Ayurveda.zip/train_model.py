import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.naive_bayes import MultinomialNB
import pickle
import os

DATA_PATH = 'dataset/enriched_ayurvedic_dataset.csv'
MODEL_PATH = 'models/dosage_predictor_model_best.pkl'
CLEAN_DATASET_PATH = 'dataset/enriched_ayurvedic_dataset_clean.csv'

df = pd.read_csv(DATA_PATH)
df = df.dropna(subset=['symptom', 'medicine'])
df['input_text'] = df['symptom'].str.lower() + ' ' + df['description'].fillna('').str.lower()

X = df['input_text']
y = df['medicine']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

pipeline = Pipeline([
    ('vectorizer', TfidfVectorizer()),
    ('classifier', MultinomialNB())
])

pipeline.fit(X_train, y_train)
y_pred = pipeline.predict(X_test)
score = pipeline.score(X_test, y_test)

print(f"\n✅ Naive Bayes Accuracy: {score:.2f}")
print(classification_report(y_test, y_pred))

os.makedirs('models', exist_ok=True)
with open(MODEL_PATH, 'wb') as f:
    pickle.dump(pipeline, f)

df_clean = df[['symptom', 'description', 'medicine', 'dose']].drop_duplicates()
os.makedirs('dataset', exist_ok=True)
df_clean.to_csv(CLEAN_DATASET_PATH, index=False)

print(f"✅ Model saved to: {MODEL_PATH}")
print(f"✅ Clean dataset saved to: {CLEAN_DATASET_PATH}")
