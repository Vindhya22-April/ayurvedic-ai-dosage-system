from flask import Flask, render_template, request, jsonify
import pickle
import pandas as pd
import os

app = Flask(__name__)

MODEL_PATH = 'models/dosage_predictor_model_best.pkl'
try:
    with open(MODEL_PATH, 'rb') as f:
        model = pickle.load(f)
except Exception as e:
    model = None
    print(f"❌ Error loading model: {e}")

DATASET_PATH = 'dataset/enriched_ayurvedic_dataset_clean.csv'
df = pd.read_csv(DATASET_PATH)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if model is None:
        return jsonify({'error': 'Model not available'}), 500

    symptom = request.form.get('symptom', '').strip().lower()
    description = request.form.get('description', '').strip().lower()

    if not symptom:
        return jsonify({'error': 'Symptom is required'}), 400

    input_text = f"{symptom} {description}"
    try:
        probs = model.predict_proba([input_text])[0]
        top_indices = probs.argsort()[-3:][::-1]
        top_classes = model.classes_[top_indices]

        results = []
        for med in top_classes:
            row = df[df['medicine'].str.lower() == med.lower()].head(1)
            dose = row['dose'].values[0] if not row.empty else "N/A"
            results.append({'medicine': med, 'dose': dose})

        return jsonify({'recommendations': results})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
